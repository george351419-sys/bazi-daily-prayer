#ifndef HOST_SERVICE_OTA_H
#define HOST_SERVICE_OTA_H
#include <stdbool.h>
bool service_ota_busy(void);
#endif
