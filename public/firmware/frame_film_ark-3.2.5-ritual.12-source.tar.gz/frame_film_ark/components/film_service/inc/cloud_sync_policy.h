/* GPL-3.0-or-later. Shared by firmware and portable host tests. */
#ifndef CLOUD_SYNC_POLICY_H
#define CLOUD_SYNC_POLICY_H
#include <stdbool.h>
#include <stdint.h>
static inline bool cloud_sync_poll_allowed(bool local, bool window, bool done, bool interactive, bool pending, bool grace) {
 return !local || (window && (!done || interactive || pending || grace));
}
static inline bool cloud_sync_can_ack(unsigned sent, unsigned current, bool hash_matches) {
 return sent != 0 && sent == current && hash_matches;
}
static inline unsigned cloud_sync_bounded_seconds(double value, unsigned minimum, unsigned maximum) {
 if(!(value>=minimum))return minimum;
 if(value>maximum)return maximum;
 return (unsigned)value;
}
static inline uint16_t cloud_sync_wait_minutes(int64_t deadline, int64_t now) {
 int64_t remaining=deadline-now;
 return remaining>0 ? (uint16_t)((remaining+59)/60) : 1;
}
static inline bool cloud_sync_retry_allowed(unsigned wakes) { return wakes < 4; }
static inline uint32_t cloud_sync_next_wake(uint32_t regular, int64_t pending_until, int64_t now) {
 if(pending_until<=0)return regular;
 uint32_t due=pending_until>now?(uint32_t)(pending_until-now):1;
 return regular==0||due<regular?due:regular;
}
/* A repeated pending response must not postpone this task's already scheduled wake. */
static inline int64_t cloud_sync_pending_deadline(int64_t previous, int64_t now, unsigned delay) {
 int64_t candidate=now+delay;
 return previous>now&&previous<candidate?previous:candidate;
}
#endif
