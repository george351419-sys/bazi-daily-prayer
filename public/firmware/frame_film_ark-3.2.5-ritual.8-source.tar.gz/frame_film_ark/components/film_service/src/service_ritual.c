/* GPL-3.0-or-later. Cached backgrounds and compact monochrome captions. */
#include "service_ritual.h"
#include "service_wifi.h"
#include "hal_epd.h"
#include "esp_heap_caps.h"
#include "nvs.h"
#include "esp_attr.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#ifndef RITUAL_PATH
#define RITUAL_PATH "/sdcard/ritual.bin"
#endif
#define PATH RITUAL_PATH
#define FRAME 172832u
#define STRIP 7680u
#define ANSWER 4800u
static unsigned answer_size(const uint8_t *h);
static SemaphoreHandle_t lock;
static int64_t answer_visible_until;
static bool take(void);
bool service_ritual_answer_holding(void) {
    if(!take())return false;
    bool holding=esp_timer_get_time()<answer_visible_until;
    xSemaphoreGive(lock);
    return holding;
}
RTC_DATA_ATTR static bool reported;
RTC_DATA_ATTR static uint8_t reported_header[64];
RTC_DATA_ATTR static uint32_t reported_day,reported_action;
RTC_DATA_ATTR static int reported_answer;
bool service_ritual_answer_visible(void) {
    if(!take())return false;
    bool visible=reported && reported_answer>=0;
    xSemaphoreGive(lock);
    return visible;
}
void service_ritual_init(void) {
    if(!lock)lock=xSemaphoreCreateMutex();
}
static uint32_t u32(const uint8_t *p) {
    return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;
}
static unsigned answer_size(const uint8_t *h) { return u32(h+36)==5?5500u:u32(h+36)>=4?6300u:ANSWER; }
/* Validate even when destination is NULL; compressed data never writes past the bitmap. */
static bool unpack_answer(const uint8_t *slot,unsigned stride,uint8_t *out) {
    unsigned n=u32(slot),i=4,w=0;
    if(n>stride-4)return false;
    while(i<n+4) {
        unsigned control=slot[i++],count=(control&127)+1;
        if(w+count>19200)return false;
        if(control&128) {
            if(i>=n+4)return false;
            if(out)memset(out+w,slot[i],count);
            i++;
        } else {
            if(i+count>n+4)return false;
            if(out)memcpy(out+w,slot+i,count);
            i+=count;
        }
        w+=count;
    }
    return w==19200;
}
static bool header(const uint8_t *h,size_t n) {
    if(!h || n<64)return false;
    uint32_t mode=u32(h+16),start=u32(h+12),anchor_mode=u32(h+40);
    static const uint8_t zero_id[16]={0};
    if(anchor_mode>1 || (anchor_mode==1 && (mode!=1 || start!=0 || !memcmp(h+44,zero_id,16))) || (mode==0 && ((uint64_t)start+28800)%86400!=3600))return false;

    return h && n>=64 && !memcmp(h,"RITUAL1\0",8) && u32(h+8)==n &&
    (u32(h+12)>=1700000000 || (u32(h+12)==0 && u32(h+16)==1 && u32(h+40)==1)) &&
    u32(h+16)<=1 && u32(h+20)>0 && u32(h+20)<=100 && u32(h+24)==64 &&
    u32(h+28)==64+2*FRAME && u32(h+32)==64+2*FRAME+2*(u32(h+36)==5?9:8)*(u32(h+36)>=3?5:1)*STRIP &&
    ((u32(h+36)==1 && u32(h+60)==0)||(u32(h+36)==2 && (u32(h+60)==2||u32(h+60)==3))||((u32(h+36)==3||u32(h+36)==4||u32(h+36)==5) && (u32(h+60)==0||u32(h+60)==2||u32(h+60)==3))) && n==64+2*FRAME+2*(u32(h+36)==5?9:8)*(u32(h+36)>=3?5:1)*STRIP+u32(h+20)*answer_size(h);
}
static bool take(void) {
    return lock&&xSemaphoreTake(lock,portMAX_DELAY)==pdTRUE;
}
static bool anchor_record(nvs_handle_t handle,const char *key,const uint8_t *h,uint32_t *start) {
    uint8_t state[20];
    size_t n=sizeof(state);
    if(nvs_get_blob(handle,key,state,&n)!=ESP_OK||n!=20||memcmp(state,h+44,16)||u32(state+16)<1700000000)return false;
    *start=u32(state+16);
    return true;
}
/* Read-only lookup: an unsuccessful install must never restart an existing run. */
static uint32_t anchor(const uint8_t *h) {
    if(u32(h+12))return u32(h+12);
    nvs_handle_t handle;
    uint32_t start=0;
    if(nvs_open("ritual",NVS_READONLY,&handle)!=ESP_OK)return 0;
    const char *keys[]= {
        "run0","run1","anchor"
    };
    /* legacy anchor is read for migration */
    for(unsigned i=0;i<3;i++)if(anchor_record(handle,keys[i],h,&start))break;
    nvs_close(handle);
    return start;
}
static bool save_anchor(const uint8_t *h,uint32_t start,const uint8_t *previous) {
    if(u32(h+12)||anchor(h))return true;
    nvs_handle_t handle;
    if(nvs_open("ritual",NVS_READWRITE,&handle)!=ESP_OK)return false;
    uint32_t ignored;
    const char *key="run0";
    if(previous&&!u32(previous+12)&&anchor_record(handle,"run0",previous,&ignored))key="run1";
    uint8_t state[20];
    memcpy(state,h+44,16);
    memcpy(state+16,&start,4);
    bool ok=nvs_set_blob(handle,key,state,sizeof(state))==ESP_OK&&nvs_commit(handle)==ESP_OK;
    nvs_close(handle);
    return ok;
}
static FILE *open_valid(const char *path,uint8_t *h) {
    FILE *f=fopen(path,"rb");
    if(!f)return NULL;
    if(fseek(f,0,SEEK_END)) {
        fclose(f);
        return NULL;
    }
    long n=ftell(f);
    rewind(f);
    if(n<64||n>RITUAL_MAX_BYTES||fread(h,1,64,f)!=64||!header(h,(size_t)n)||!anchor(h)) {
        fclose(f);
        return NULL;
    }
    return f;
}
/* A torn replacement (including its NVS commit) falls back to the previous run. */
static FILE *open_package(uint8_t *h) {
    FILE *f=open_valid(PATH,h);
    if(f)return f;
    f=open_valid(PATH ".bak",h);
    if(!f)return NULL;
    unlink(PATH);
    rename(PATH ".bak",PATH);
    return f;
}
bool service_ritual_available(void) {
    uint8_t h[64];
    if(!take())return false;
    FILE *f=open_package(h);
    bool ok=f!=NULL;
    if(f)fclose(f);
    xSemaphoreGive(lock);
    return ok;
}
bool service_ritual_install(const uint8_t *b,size_t n) {
    if(n>RITUAL_MAX_BYTES||!header(b,n))return false;
    static const uint8_t palette[16]= {
        0,255,252,224,3,28
    };
    for(unsigned i=0;i<2;i++) {
        const uint8_t *p=b+64+i*FRAME;
        if(u32(p)!=172800||p[4]!=0xd0||p[5]!=2||p[6]!=0xe0||p[7]!=1||p[8]!=6||memcmp(p+9,"\0\0\0\0\0\0\0",7)||memcmp(p+16,palette,16))return false;
        for(unsigned j=32;j<FRAME;j++)if((p[j]>>4)>5||(p[j]&15)>5)return false;
    }
    if(u32(b+36)>=4)for(unsigned i=0;i<u32(b+20);i++)if(!unpack_answer(b+u32(b+32)+i*answer_size(b),answer_size(b),NULL))return false;
    if(!take())return false;
    uint8_t previous[64];
    FILE *old=open_package(previous);
    bool had_valid=old!=NULL;
    if(old)fclose(old);
    uint32_t start=anchor(b);
    time_t now=time(NULL);
    if(!start) {
        if(now<1700000000) {
            xSemaphoreGive(lock);
            return false;
        }
        start=(uint32_t)now;
    }
    FILE *f=fopen(PATH ".tmp","wb");
    bool ok=false;
    if(f) {
        bool wrote=fwrite(b,1,n,f)==n;
        bool flushed=fflush(f)==0;
        bool synced=fsync(fileno(f))==0;
        bool closed=fclose(f)==0;
        ok=wrote&&flushed&&synced&&closed;
    }
    bool moved=false,installed=false;
    if(ok) {
        unlink(PATH ".bak");
        moved=rename(PATH,PATH ".bak")==0;
        if(!moved&&errno!=ENOENT)ok=false;
        if(ok) {
            installed=rename(PATH ".tmp",PATH)==0;
            ok=installed;
        }
        if(ok)ok=save_anchor(b,start,had_valid?previous:NULL);
    }
    if(!ok) {
        if(installed)unlink(PATH);
        if(moved)rename(PATH ".bak",PATH);
        unlink(PATH ".tmp");
    }
    else  {
        unlink(PATH ".bak");
        reported=false;
    }
    xSemaphoreGive(lock);
    return ok;
}
bool service_ritual_disable(void) {
    if(!take())return false;
    bool ok=unlink(PATH)==0||errno==ENOENT;
    if(unlink(PATH ".bak")!=0&&errno!=ENOENT)ok=false;
    if(unlink(PATH ".tmp")!=0&&errno!=ENOENT)ok=false;
    if(ok)reported=false;
    xSemaphoreGive(lock);
    return ok;
}
bool service_ritual_report(uint32_t *d,uint32_t *a,int *answer) {
    if(!take())return false;
    uint8_t h[64];
    FILE *f=open_package(h);
    bool ok=f&&reported&&!memcmp(h,reported_header,64);
    if(ok) {
        *d=reported_day;
        *a=reported_action;
        *answer=reported_answer;
    }
    if(f)fclose(f);
    xSemaphoreGive(lock);
    return ok;
}
uint32_t service_ritual_started_at(void) {
    uint8_t h[64];
    if(!take())return 0;
    FILE *f=open_package(h);
    uint32_t start=f?anchor(h):0;
    if(f)fclose(f);
    xSemaphoreGive(lock);
    return start;
}
static bool position(const uint8_t *h,uint32_t *day,uint32_t *action,uint32_t *key) {
    time_t now=time(NULL);
    uint32_t start=anchor(h);
    if(!start||now<1700000000)return false;
    unsigned slots=u32(h+36)==5?9:8;
    if(u32(h+16)) {
        uint32_t step=now>start?(uint32_t)(now-start)/120:0;
        *day=(step/slots)%2;
        *action=step%slots;
        *key=step;
        if(u32(h+36)>=2&&(u32(h+60)&1)){*action=UINT32_MAX;*key=step/slots;}
        return true;
    }
    int64_t local=(int64_t)now+28800,base=(int64_t)start+28800;
    int64_t date=(local-3600)/86400,first=(base-3600)/86400,d=date-first;
    *day=d<0?0:d>1?1:(uint32_t)d;
    unsigned hour=(local%86400)/3600;
    *action=d>=0&&d<2?((hour>=7&&(hour<23||slots==9))?(hour-7)/2:slots==9&&hour==0?8:UINT32_MAX):UINT32_MAX;
    *key=(uint32_t)(date*16+(*action==UINT32_MAX?15:*action));
    if(u32(h+36)>=2&&(u32(h+60)&1)){*action=UINT32_MAX;*key=(uint32_t)date;}
    return true;
}
bool service_ritual_position(uint32_t *d,uint32_t *a,uint32_t *k) {
    uint8_t h[64];
    if(!take())return false;
    FILE *f=open_package(h);
    bool ok=f&&position(h,d,a,k);
    if(f)fclose(f);
    xSemaphoreGive(lock);
    return ok;
}
uint32_t service_ritual_action_slots(void) {
    if(!take())return 8;
    uint8_t h[64];FILE *f=open_package(h);uint32_t n=f&&u32(h+36)==5?9:8;
    if(f)fclose(f);
    xSemaphoreGive(lock);return n;
}
uint32_t service_ritual_action_variants(void) {
    if(!take())return 1;
    uint8_t h[64];FILE *f=open_package(h);uint32_t n=f&&u32(h+36)>=3?5:1;
    if(f)fclose(f);
    xSemaphoreGive(lock);
    return n;
}
uint32_t service_ritual_answer_count(void) {
    uint8_t h[64];
    if(!take())return 0;
    FILE *f=open_package(h);
    uint32_t n=f?u32(h+20):0;
    if(f)fclose(f);
    xSemaphoreGive(lock);
    return n;
}
/* Portrait pixel -> rotate 270 degrees -> 720x480 row-major. */
static void pixel(uint8_t *film,unsigned x,unsigned y,unsigned color) {
    unsigned p=x*720+719-y;
    uint8_t *v=film+32+p/2;
    if(p&1)*v=(*v&0xf0)|color;
    else *v=(*v&15)|(color<<4);
}
void service_ritual_render(uint32_t day,uint32_t action,int answer) {
    if(action==0xffff)action=UINT32_MAX;
    if(day>1||!take())return;
    uint8_t h[64];
    FILE *f=open_package(h);
    if(!f) {
        xSemaphoreGive(lock);
        return;
    }
    if(answer< -1||(answer>=0&&(unsigned)answer>=u32(h+20))) {
        fclose(f);
        xSemaphoreGive(lock);
        return;
    }
    if(u32(h+36)>=2&&(u32(h+60)&1))action=UINT32_MAX;
    uint8_t *frame=heap_caps_malloc(FRAME,MALLOC_CAP_SPIRAM),*strip=heap_caps_malloc(u32(h+36)>=4?19200:STRIP,MALLOC_CAP_SPIRAM);
    bool ok=frame&&strip;
    if(ok) {
        ok=fseek(f,64+day*FRAME,SEEK_SET)==0&&fread(frame,1,FRAME,f)==FRAME;
    }
    if(ok&&answer>=0) {
        memset(frame+32,0x11,FRAME-32);
        uint8_t *packed=u32(h+36)>=4?heap_caps_malloc(answer_size(h),MALLOC_CAP_SPIRAM):NULL;
        uint8_t *target=u32(h+36)>=4?packed:strip;
        ok=target&&fseek(f,u32(h+32)+(unsigned)answer*answer_size(h),SEEK_SET)==0&&fread(target,1,answer_size(h),f)==answer_size(h);
        if(ok&&packed)ok=unpack_answer(packed,answer_size(h),strip);
        free(packed);
        if(ok)for(unsigned y=0;y<(u32(h+36)>=4?320u:80u);y++)for(unsigned x=0;x<480;x++)pixel(frame,x,y+(u32(h+36)>=4?200:280),(strip[y*60+x/8]&(0x80>>(x%8)))?0:1);
    }
    else if(ok&&action<(u32(h+36)==5?45u:u32(h+36)>=3?40u:8u)&&!(u32(h+36)>=2&&(u32(h+60)&1))) {
        ok=fseek(f,u32(h+28)+(day*(u32(h+36)==5?45:u32(h+36)>=3?40:8)+action)*STRIP,SEEK_SET)==0&&fread(strip,1,STRIP,f)==STRIP;
        if(ok)for(unsigned y=8;y<120;y++)for(unsigned x=24;x<456;x++)pixel(frame,x,y+552,(strip[y*60+x/8]&(0x80>>(x%8)))?0:1);
    }
    fclose(f);
    xSemaphoreGive(lock);
    if(ok) {
        hal_epd_display_init();
        hal_epd_display_film(frame);
        hal_epd_pwroff();
        if(take()) {
            uint8_t current[64];
            f=open_package(current);
            if(f&&!memcmp(h,current,64)) {
                memcpy(reported_header,h,64);
                reported_day=day;
                reported_action=action;
                reported_answer=answer;
                answer_visible_until=answer>=0?esp_timer_get_time()+30000000:0;
                reported=true;
                service_wifi_cloud_rendered();
            }
            if(f)fclose(f);
            xSemaphoreGive(lock);
        }
    }
    free(frame);
    free(strip);
}
uint32_t service_ritual_wake_seconds(uint32_t fallback) {
    uint8_t h[64];
    if(!take())return fallback;
    FILE *f=open_package(h);
    uint32_t start=f?anchor(h):0;
    if(f)fclose(f);
    xSemaphoreGive(lock);
    if(!f)return fallback;
    time_t now=time(NULL);
    if(now<1700000000||!start)return 600;
    bool photo_only=u32(h+36)>=2&&(u32(h+60)&1);
    if(u32(h+16)){uint32_t interval=photo_only?(u32(h+36)==5?1080:960):120;return now<start?start-(uint32_t)now:interval-((uint32_t)now-start)%interval;}
    if(photo_only){uint32_t seconds=((uint32_t)now+28800)%86400;return seconds<3600?3600-seconds:90000-seconds;}
    if(((int64_t)now+28800-3600)/86400-((int64_t)start+28800-3600)/86400>1)return 600;
    unsigned seconds=(now+28800)%86400,next=90000;
    const unsigned hours[]= {
        1,7,9,11,13,15,17,19,21,23
    };
    for(unsigned i=0;i<10;i++)if(hours[i]*3600>seconds) {
        next=hours[i]*3600;
        break;
    }
    return next-seconds;
}
uint16_t service_ritual_wake_minutes(uint16_t fallback) {
    return (uint16_t)((service_ritual_wake_seconds((uint32_t)fallback*60)+59)/60);
}
