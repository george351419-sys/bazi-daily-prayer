#ifndef SERVICE_RITUAL_H
#define SERVICE_RITUAL_H
#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#define RITUAL_MAX_BYTES 1600000u
/* RITUAL1 layout v1 prayer, v2 photo, v4 lossless-packed centered 480x320 answer+reading, v3 five variants (80 strips); header[60..63]: bit0 hide action, bit1 photo.
 * Compiled portrait assets; all EPD access remains on film_task. */
bool service_ritual_answer_holding(void);
bool service_ritual_answer_visible(void);
void service_ritual_init(void);
bool service_ritual_install(const uint8_t *bytes, size_t length);
bool service_ritual_available(void);
bool service_ritual_disable(void);
bool service_ritual_position(uint32_t *day, uint32_t *action, uint32_t *key);
uint32_t service_ritual_answer_count(void);
uint32_t service_ritual_action_slots(void);
uint32_t service_ritual_action_variants(void);
uint32_t service_ritual_started_at(void);
bool service_ritual_report(uint32_t *day, uint32_t *action, int *answer);
void service_ritual_render(uint32_t day, uint32_t action, int answer);
uint32_t service_ritual_wake_seconds(uint32_t fallback);
uint16_t service_ritual_wake_minutes(uint16_t fallback);
#endif
