/* GPL-3.0-or-later. Shared by firmware and portable host tests. */
#ifndef CLOUD_SYNC_POLICY_H
#define CLOUD_SYNC_POLICY_H
#include <stdbool.h>
static inline bool cloud_sync_poll_allowed(bool local, bool window, bool done, bool interactive, bool pending, bool grace) {
 return !local || (window && (!done || interactive || pending || grace));
}
static inline bool cloud_sync_can_ack(unsigned sent, unsigned current, bool hash_matches) {
 return sent != 0 && sent == current && hash_matches;
}
#endif
