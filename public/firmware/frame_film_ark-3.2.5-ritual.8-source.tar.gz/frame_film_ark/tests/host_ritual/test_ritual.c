#include <assert.h>
#include <stdint.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static time_t clock_now=1793206800;
static int64_t monotonic_us=1000000;
int64_t esp_timer_get_time(void){return monotonic_us;}
static time_t fake_time(time_t *out){if(out)*out=clock_now;return clock_now;}
#include <unistd.h>
static int fail_sync;
static int test_fsync(int fd){return fail_sync?-1:fsync(fd);}
#define fsync test_fsync
#define time fake_time
#include "../../components/film_service/src/service_ritual.c"
#undef time
#undef fsync
static unsigned receipt_events;
void service_wifi_cloud_rendered(void){receipt_events++;}
static unsigned renders;
static const char *expected;
static uint8_t *replacement;static size_t replacement_size;
void hal_epd_display_init(void){}
void hal_epd_pwroff(void){}
void hal_epd_display_film(const unsigned char *frame){
 FILE *f=fopen(expected,"rb");assert(f);unsigned char *wanted=malloc(FRAME);assert(fread(wanted,1,FRAME,f)==FRAME);fclose(f);assert(!memcmp(frame,wanted,FRAME));free(wanted);renders++;if(replacement){assert(service_ritual_install(replacement,replacement_size));replacement=NULL;}
}
int main(int argc,char **argv){
 assert(argc==5||argc==6);FILE *f=fopen(argv[1],"rb");assert(f);fseek(f,0,SEEK_END);size_t n=ftell(f);rewind(f);uint8_t *b=malloc(n);assert(fread(b,1,n,f)==n);fclose(f);
 unsigned slots=u32(b+36)==5?9:8;
 bool photo_only=u32(b+36)>=2&&(u32(b+60)&1);
 service_ritual_init();assert(!service_ritual_available());assert(service_ritual_install(b,n));assert(service_ritual_available());assert(service_ritual_answer_count()==100);assert(service_ritual_wake_minutes(10)==(photo_only?slots*2:2));
 uint32_t d,a,k;time_t start=clock_now;
 clock_now=start+119;assert(service_ritual_position(&d,&a,&k)&&d==0&&a==(photo_only?UINT32_MAX:0));
 for(unsigned step=0;step<33;step++){clock_now=start+step*120;assert(service_ritual_position(&d,&a,&k));assert(d==(step/slots)%2);assert(a==(photo_only?UINT32_MAX:step%slots));assert(k==(photo_only?step/slots:step));}
 // Re-installation must retain the first connection anchor.
 assert(service_ritual_install(b,n));assert(service_ritual_position(&d,&a,&k));assert(k==(photo_only?32/slots:32));
 expected=argv[2];service_ritual_render(0,0,-1);expected=argv[3];service_ritual_render(1,slots-1,-1);expected=argv[4];service_ritual_render(0,0,0);assert(renders==3);assert(receipt_events==3);assert(service_ritual_answer_holding());clock_now-=86400;assert(service_ritual_answer_holding());clock_now+=86400;monotonic_us+=29000000;assert(service_ritual_answer_holding());monotonic_us+=1000000;assert(!service_ritual_answer_holding());
 if(argc==6){expected=argv[5];service_ritual_render(1,slots*5-1,-1);assert(renders==4);assert(!service_ritual_answer_visible());expected=argv[4];service_ritual_render(0,0,0);}
 // Sleep is aligned to the original slot, rather than adding two minutes after every refresh.
 clock_now=start+19;assert(service_ritual_wake_seconds(600)==(photo_only?slots*120-19:101));
 clock_now=start+119;assert(service_ritual_wake_seconds(600)==(photo_only?slots*120-119:1));
 uint32_t rd,ra;int answer;assert(service_ritual_report(&rd,&ra,&answer)&&answer==0);
 uint8_t *next=malloc(n);memcpy(next,b,n);next[44]^=0x5a;
 // Disk failure and NVS failure leave the previous package and its time anchor intact.
 clock_now=start+400;fail_sync=1;assert(!service_ritual_install(next,n));fail_sync=0;
 assert(service_ritual_started_at()==(uint32_t)start);
 nvs_fail_commit=1;assert(!service_ritual_install(next,n));nvs_fail_commit=0;
 assert(service_ritual_available()&&service_ritual_started_at()==(uint32_t)start);
 // Simulate power loss after replacing the file but before committing its anchor.
 assert(rename(RITUAL_PATH,RITUAL_PATH ".bak")==0);f=fopen(RITUAL_PATH,"wb");assert(f);assert(fwrite(next,1,n,f)==n);fclose(f);
 assert(service_ritual_available()&&service_ritual_started_at()==(uint32_t)start);
 // Replacement while a prior frame is being sent must not report that frame as the new package.
 replacement=next;replacement_size=n;expected=argv[2];service_ritual_render(0,0,-1);
 assert(!service_ritual_report(&rd,&ra,&answer));assert(service_ritual_started_at()==(uint32_t)clock_now);
 service_ritual_render(0,0,-1);assert(service_ritual_report(&rd,&ra,&answer)&&answer==-1);
 assert(service_ritual_disable());assert(!service_ritual_available());assert(!service_ritual_report(&rd,&ra,&answer));assert(service_ritual_wake_seconds(777)==777);
 assert(service_ritual_install(b,n));free(next);
 // Shanghai 01:00 day boundary, quiet hours, and expired-cache retry.
 uint8_t daily[64];memcpy(daily,b,64);daily[36]=slots==9?5:1;daily[60]=0;uint32_t epoch=1793206800,mode=0;memcpy(daily+12,&epoch,4);memcpy(daily+16,&mode,4);
 clock_now=epoch+6*3600-1;assert(position(daily,&d,&a,&k)&&d==0&&a==UINT32_MAX);
 clock_now=epoch+6*3600;assert(position(daily,&d,&a,&k)&&a==0);
 clock_now=epoch+22*3600;assert(position(daily,&d,&a,&k)&&a==(slots==9?8:UINT32_MAX));
 clock_now=epoch+86400-1;assert(position(daily,&d,&a,&k)&&d==0&&a==(slots==9?8:UINT32_MAX));
 clock_now=epoch+86400;assert(position(daily,&d,&a,&k)&&d==1&&a==UINT32_MAX);
 clock_now=epoch+2*86400+8*3600;assert(position(daily,&d,&a,&k)&&d==1&&a==UINT32_MAX);

 // v2 photo-only must preserve every six-colour pixel, even if a stale caller supplies action 0.
 uint8_t *photo=malloc(n);memcpy(photo,b,n);photo[36]=u32(b+36)>=3?u32(b+36):2;photo[60]=3;
 assert(service_ritual_install(photo,n));uint32_t photo_start=service_ritual_started_at();
 clock_now=photo_start+60;assert(service_ritual_position(&d,&a,&k)&&d==0&&a==UINT32_MAX&&k==0);assert(service_ritual_wake_seconds(600)==slots*120-60);
 clock_now=photo_start+slots*120;assert(service_ritual_position(&d,&a,&k)&&d==1&&a==UINT32_MAX&&k==1);
 f=fopen(RITUAL_PATH ".full","wb");assert(f);assert(fwrite(photo+64,1,FRAME,f)==FRAME);fclose(f);
 expected=RITUAL_PATH ".full";service_ritual_render(0,0,-1);assert(service_ritual_report(&rd,&ra,&answer)&&ra==UINT32_MAX);
 photo[60]=7;assert(!service_ritual_install(photo,n));free(photo);unlink(RITUAL_PATH ".full");
 if(u32(b+36)>=4){uint32_t at=u32(b+32),saved=u32(b+at);b[at]=0xff;b[at+1]=0xff;assert(!service_ritual_install(b,n));memcpy(b+at,&saved,4);assert(service_ritual_available());}
 assert(!service_ritual_install(b,n-1));b[64+32]=255;assert(!service_ritual_install(b,n));assert(service_ritual_available());free(b);unlink(RITUAL_PATH);
 puts("PASS: actual C compositor, 33 slots, second-based wake, disk/NVS failure rollback, torn-install recovery, replacement/report race, photo-only pixel preservation and mode disable");
}
