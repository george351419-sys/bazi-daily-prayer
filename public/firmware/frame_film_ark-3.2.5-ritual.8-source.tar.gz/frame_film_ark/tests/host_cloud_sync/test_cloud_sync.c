#include <assert.h>
#include "cloud_sync_policy.h"
int main(void){
 assert(!cloud_sync_poll_allowed(1,1,1,0,0,0));
 assert(cloud_sync_poll_allowed(1,1,1,1,0,0));
 assert(cloud_sync_poll_allowed(1,1,1,0,1,0));
 assert(cloud_sync_poll_allowed(1,1,1,0,0,1));
 assert(!cloud_sync_poll_allowed(1,0,0,1,1,1));
 assert(cloud_sync_poll_allowed(0,0,1,0,0,0));
 assert(cloud_sync_can_ack(4,4,1));assert(!cloud_sync_can_ack(3,4,1));assert(!cloud_sync_can_ack(4,4,0));assert(!cloud_sync_can_ack(0,0,1));
}
