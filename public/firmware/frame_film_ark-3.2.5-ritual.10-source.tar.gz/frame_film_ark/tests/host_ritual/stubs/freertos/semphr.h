typedef int SemaphoreHandle_t;
static inline int xSemaphoreCreateMutex(void){return 1;}
static inline int xSemaphoreTake(int lock,int delay){(void)lock;(void)delay;return 1;}
static inline void xSemaphoreGive(int lock){(void)lock;}
