#include <stddef.h>
#include <string.h>
#define ESP_OK 0
#define NVS_READWRITE 1
#define NVS_READONLY 0
typedef int nvs_handle_t;
static unsigned char nvs_values[3][20],nvs_pending[20];
static int nvs_saved[3],nvs_pending_key=-1,nvs_fail_commit;
static inline int key_index(const char *key){return !strcmp(key,"run0")?0:!strcmp(key,"run1")?1:2;}
static inline int nvs_open(const char *ns,int mode,nvs_handle_t *h){(void)ns;(void)mode;*h=1;return 0;}
static inline int nvs_get_blob(int h,const char *key,void *out,size_t *n){(void)h;int k=key_index(key);if(!nvs_saved[k])return -1;memcpy(out,nvs_values[k],20);*n=20;return 0;}
static inline int nvs_set_blob(int h,const char *key,const void *v,size_t n){(void)h;nvs_pending_key=key_index(key);memcpy(nvs_pending,v,n);return 0;}
static inline int nvs_commit(int h){(void)h;if(nvs_fail_commit){nvs_pending_key=-1;return -1;}if(nvs_pending_key>=0){memcpy(nvs_values[nvs_pending_key],nvs_pending,20);nvs_saved[nvs_pending_key]=1;nvs_pending_key=-1;}return 0;}
static inline void nvs_close(int h){(void)h;}
