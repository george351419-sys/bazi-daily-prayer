void hal_epd_display_init(void);
void hal_epd_display_film(const unsigned char *data);
void hal_epd_pwroff(void);
