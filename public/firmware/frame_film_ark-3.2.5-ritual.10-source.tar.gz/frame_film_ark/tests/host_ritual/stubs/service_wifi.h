void service_wifi_cloud_rendered(void);
