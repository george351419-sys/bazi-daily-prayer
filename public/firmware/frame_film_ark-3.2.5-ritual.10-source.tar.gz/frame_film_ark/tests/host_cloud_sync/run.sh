#!/bin/sh
set -eu
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
bin=$(mktemp /tmp/ark-cloud-sync.XXXXXX)
trap 'rm -f "$bin"' EXIT HUP INT TERM
cc -std=c11 -Wall -Wextra -I "$here/../../components/film_service/inc" "$here/test_cloud_sync.c" -o "$bin"
"$bin"
