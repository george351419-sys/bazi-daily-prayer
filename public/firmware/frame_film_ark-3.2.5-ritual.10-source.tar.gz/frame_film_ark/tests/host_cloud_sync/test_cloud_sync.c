#include <assert.h>
#include "cloud_sync_policy.h"
int main(void){
 assert(cloud_sync_retry_allowed(1));assert(cloud_sync_retry_allowed(3));assert(!cloud_sync_retry_allowed(4));
 assert(cloud_sync_wait_minutes(1420,1000)==7);
 assert(cloud_sync_wait_minutes(1000,1420)==1);
 assert(cloud_sync_bounded_seconds(-1,60,900)==60);
 assert(cloud_sync_bounded_seconds(10000,30,180)==180);
 // A scheduled wake polls without BLE for its finite window, then stops.
 assert(cloud_sync_poll_allowed(1,1,1,1,0,0));
 assert(!cloud_sync_poll_allowed(1,0,1,1,0,0));

 assert(!cloud_sync_poll_allowed(1,1,1,0,0,0));
 assert(cloud_sync_poll_allowed(1,1,1,1,0,0));
 assert(cloud_sync_poll_allowed(1,1,1,0,1,0));
 assert(cloud_sync_poll_allowed(1,1,1,0,0,1));
 assert(!cloud_sync_poll_allowed(1,0,0,1,1,1));
 assert(cloud_sync_poll_allowed(0,0,1,0,0,0));
 assert(cloud_sync_can_ack(4,4,1));assert(!cloud_sync_can_ack(3,4,1));assert(!cloud_sync_can_ack(4,4,0));assert(!cloud_sync_can_ack(0,0,1));
}
