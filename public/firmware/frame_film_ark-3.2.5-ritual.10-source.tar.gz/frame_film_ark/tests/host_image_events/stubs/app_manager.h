#include "app_interface.h"
void app_state_save(void);
app_id_t app_manager_get_current(void);

#include <stdbool.h>
static inline bool app_manager_boot_advance_pending(void){return false;}
