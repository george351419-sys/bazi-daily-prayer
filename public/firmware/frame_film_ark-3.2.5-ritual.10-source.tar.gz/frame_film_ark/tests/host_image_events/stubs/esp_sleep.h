#define ESP_SLEEP_WAKEUP_TIMER 1
static inline int esp_sleep_get_wakeup_cause(void){return 0;}
