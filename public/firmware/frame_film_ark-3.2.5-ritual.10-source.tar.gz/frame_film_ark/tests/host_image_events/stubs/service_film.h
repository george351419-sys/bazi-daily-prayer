#include <stdint.h>
#include <stdbool.h>
void service_film_display(uint32_t id);

static inline int service_film_is_busy(void){return 0;}
void service_film_cancel_pending(void);
bool service_film_ritual(uint32_t d,uint32_t a,int answer);
