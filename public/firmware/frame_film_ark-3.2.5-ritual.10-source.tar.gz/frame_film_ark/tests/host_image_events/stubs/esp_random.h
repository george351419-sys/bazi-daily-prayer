#include <stdint.h>
static inline uint32_t esp_random(void){return 12;}
