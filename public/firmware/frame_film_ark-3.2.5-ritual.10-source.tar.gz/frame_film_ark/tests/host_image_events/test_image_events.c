/* Exercise real image-app callbacks with storage and display collaborators stubbed. */
#include <assert.h>
#include "../../components/film_app/core/app_display_policy.h"
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "../../components/film_app/apps/image/app_image.c"

static bool ritual_active,answer_hold;
static uint32_t ritual_slots=8;
uint32_t service_ritual_action_slots(void){return ritual_slots;}
uint32_t service_ritual_action_variants(void){return 5;}
bool service_ritual_answer_holding(void){return answer_hold;}
static uint32_t ritual_day,ritual_action,ritual_key;
static int ritual_draws,last_answer;
static uint32_t last_action;
static bool reject_render,render_report=true;
bool service_ritual_available(void){return ritual_active;}
bool service_ritual_position(uint32_t *d,uint32_t *a,uint32_t *k){*d=ritual_day;*a=ritual_action;*k=ritual_key;return true;}
uint32_t service_ritual_answer_count(void){return 100;}
void service_film_cancel_pending(void){}
bool service_film_ritual(uint32_t d,uint32_t a,int answer){assert(d==ritual_day);assert(a%ritual_slots==ritual_action);if(reject_render)return false;ritual_draws++;last_answer=answer;last_action=a;answer_hold=answer>=0;return true;}
bool service_ritual_report(uint32_t *d,uint32_t *a,int *answer){*d=ritual_day;*a=last_action;*answer=last_answer;return render_report;}
int service_file_find_id(const char *name,uint32_t *id){(void)name;*id=0;return 0;}
struct host_param g_service_param;
static uint32_t count, current_id, displayed[8];
static uint8_t load_state;
static unsigned display_count;
uint32_t service_file_get_count(void) { return count; }
uint32_t service_file_get_current_id(void) { return current_id; }
uint8_t service_file_get_load_complete(void) { return load_state; }
void service_film_display(uint32_t id) { assert(display_count < 8); displayed[display_count++] = id; }
void app_state_save(void) { }
app_id_t app_manager_get_current(void) { return APP_ID_IMAGE; }

static void reset(uint32_t files, uint8_t state)
{
    count = files;
    current_id = files ? files - 1 : 0;
    load_state = state;
    display_count = 0;
    m_image = m_image_default;
}
static void list(int saving)
{
    app_event_t event = { .type = APP_EVT_SYS, .cmd = SYS_EVT_FILE_LIST,
                          .len = sizeof(uint32_t) };
    memcpy(event.payload, &count, sizeof(count));
    if(saving) { event.payload[sizeof(count)] = SYS_FILE_LIST_SAVE_PENDING; event.len++; }
    g_app_image_entry.on_event(&event);
}
static void saved(uint8_t auto_load)
{
    app_event_t event = { .type = APP_EVT_SYS, .cmd = SYS_EVT_FILE_SAVED, .len = 1 };
    event.payload[0] = auto_load;
    g_app_image_entry.on_event(&event);
}
int main(void)
{
    assert(!app_cloud_can_open(false,false,true)); /* menu/settings */
    assert(!app_cloud_can_open(false,true,true)); /* running image handles its own update */
    assert(app_cloud_can_open(true,false,false)); /* startup cache */
    assert(app_cloud_can_open(false,true,false));
    assert(app_page_holds_auto_sleep(true,false));assert(app_page_holds_auto_sleep(false,true));
    assert(!app_page_holds_auto_sleep(false,false));
    /* New-file and same-name overwrite: invalidated cache must queue only the target. */
    reset(2, FILE_LOAD_STATE_NONE); list(1); assert(display_count == 0);
    saved(1); assert(display_count == 1 && displayed[0] == 1);
    reset(2, FILE_LOAD_STATE_NONE); current_id = 0; list(1); saved(1);
    assert(display_count == 1 && displayed[0] == 0);
    /* Silent saves must remain silent, including the first file in an empty app. */
    reset(2, FILE_LOAD_STATE_NONE); list(1); saved(0); assert(display_count == 0);
    reset(0, FILE_LOAD_STATE_NONE); g_app_image_entry.on_enter();
    assert(display_count == 0); count = 1; current_id = 0; list(1); saved(0);
    assert(display_count == 0);
    /* Initial entry and ordinary delayed list, recovery and deletion retain their behavior. */
    reset(1, FILE_LOAD_STATE_NONE); g_app_image_entry.on_enter();
    assert(display_count == 1 && displayed[0] == 0);
    reset(0, FILE_LOAD_STATE_NONE); g_app_image_entry.on_enter();
    count = 1; list(0); assert(display_count == 1 && displayed[0] == 0);
    reset(1, FILE_LOAD_STATE_FAILED); g_app_image_entry.on_enter(); list(0); assert(display_count == 1);
    reset(1, FILE_LOAD_STATE_NONE); m_image.file_id = 4; g_app_image_entry.on_enter(); list(0);
    assert(display_count == 1 && displayed[0] == 0 && m_image.file_id == 0);
    reset(0, FILE_LOAD_STATE_NONE); list(0); assert(display_count == 0);
    reset(1, FILE_LOAD_STATE_DONE); list(0); assert(display_count == 0);
    ritual_active=true;ritual_day=1;ritual_action=3;ritual_key=11;
    assert(app_image_enter_block_reason()==NULL);assert(app_image_prepare_open("today.film"));
    g_app_image_entry.on_enter();assert(ritual_draws==1&&last_answer==-1);
    app_event_t key={.type=APP_EVT_INPUT,.input=INPUT_PRESS_UP};g_app_image_entry.on_event(&key);assert(last_answer==12);
    g_app_image_entry.on_event(&key);assert(last_answer==13);
    key.input=INPUT_PRESS_DOWN;g_app_image_entry.on_event(&key);assert(last_answer==-1&&last_action==ritual_action+8);
    for(unsigned variant=2;variant<=5;variant++){g_app_image_entry.on_event(&key);assert(last_action==ritual_action+(variant%5)*8);}
    g_app_image_entry.on_event(&key);assert(last_action==ritual_action+8);
    int selected_draws=ritual_draws;g_app_image_entry.on_tick();assert(ritual_draws==selected_draws);
    key.input=INPUT_PRESS_UP;g_app_image_entry.on_event(&key);assert(last_answer>=0&&last_action==ritual_action+8);
    answer_hold=false;g_app_image_entry.on_tick();assert(last_answer==-1&&last_action==ritual_action+8);
    key.input=INPUT_PRESS_DOWN;g_app_image_entry.on_event(&key);
    ritual_key++;ritual_action++;g_app_image_entry.on_tick();assert(last_answer==-1);int draws=ritual_draws;g_app_image_entry.on_tick();assert(draws==ritual_draws);
    // A full queue must not advance the remembered slot; retry when it becomes available.
    reject_render=true;ritual_key++;ritual_action++;draws=ritual_draws;g_app_image_entry.on_tick();assert(ritual_draws==draws&&m_ritual_key!=ritual_key);
    reject_render=false;g_app_image_entry.on_tick();assert(ritual_draws==draws+1&&m_ritual_key==ritual_key);
    render_report=false;g_app_image_entry.on_tick();assert(ritual_draws==draws+2);render_report=true;
    // Pressing up at the exact boundary must not be undone by the following tick.
    ritual_key++;key.input=INPUT_PRESS_UP;g_app_image_entry.on_event(&key);assert(last_answer>=0&&m_ritual_key==ritual_key);draws=ritual_draws;g_app_image_entry.on_tick();assert(ritual_draws==draws&&last_answer>=0);
    // Crossing a slot must preserve the answer until the 30-second hold expires.
    ritual_key++;ritual_action++;draws=ritual_draws;g_app_image_entry.on_tick();assert(ritual_draws==draws&&last_answer>=0);
    answer_hold=false;g_app_image_entry.on_tick();assert(last_answer==-1&&m_ritual_key==ritual_key);
    // A new package can occupy the exact same two-minute slot.
    app_event_t download={.type=APP_EVT_SYS,.cmd=SYS_EVT_WIFI_DL_DONE};draws=ritual_draws;g_app_image_entry.on_event(&download);assert(ritual_draws==draws+1);
    ritual_slots=9;ritual_action=8;ritual_key++;answer_hold=false;
    g_app_image_entry.on_tick();assert(last_action==8&&last_answer==-1);
    key.input=INPUT_PRESS_DOWN;g_app_image_entry.on_event(&key);assert(last_action==17);
    for(unsigned i=0;i<3;i++)g_app_image_entry.on_event(&key);
    assert(last_action==44);key.input=INPUT_PRESS_UP;g_app_image_entry.on_event(&key);assert(last_action==44&&last_answer>=0);
    puts("PASS: ritual enter without film, up draws without repeat, down cycles five, answer returns to selected action, minute tick deduplicates");
    puts("PASS: image events (new, overwrite, silent, first file, initial, recovery, delete)");
    return 0;
}
