/* GPL-3.0-or-later. Shared by firmware and portable host tests. */
#ifndef CLOUD_SYNC_POLICY_H
#define CLOUD_SYNC_POLICY_H
#include <stdbool.h>
#include <stdint.h>
static inline bool cloud_sync_poll_allowed(bool local, bool window, bool done, bool interactive, bool pending, bool grace) {
 return !local || (window && (!done || interactive || pending || grace));
}
static inline bool cloud_sync_can_ack(unsigned sent, unsigned current, bool hash_matches) {
 return sent != 0 && sent == current && hash_matches;
}
static inline unsigned cloud_sync_bounded_seconds(double value, unsigned minimum, unsigned maximum) {
 if(!(value>=minimum))return minimum;
 if(value>maximum)return maximum;
 return (unsigned)value;
}
static inline uint16_t cloud_sync_wait_minutes(int64_t deadline, int64_t now) {
 int64_t remaining=deadline-now;
 return remaining>0 ? (uint16_t)((remaining+59)/60) : 1;
}
static inline bool cloud_sync_retry_allowed(unsigned wakes) { return wakes < 4; }
#endif
