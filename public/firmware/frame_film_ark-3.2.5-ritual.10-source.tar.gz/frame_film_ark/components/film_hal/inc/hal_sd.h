#ifndef __HAL_SD_H__
#define __HAL_SD_H__

#include <stdint.h>




/*********************************************************************
 * INCLUDES
 */


/*********************************************************************
 * CPPMIX
 */
#ifdef __cplusplus
extern "C" {
#endif

/*********************************************************************
 * MACROS
 */
 #define MOUNT_POINT             "/sdcard"
 #define SD_MOUNT                (1)
 #define SD_UNMOUNT              (0)

/*********************************************************************
* TYPEDEFS
*/


/*********************************************************************
 * CONSTANTS
 */


/*********************************************************************
 * LOCAL VARIABLES
 */


/*********************************************************************
 * GLOBAL VARIABLES
 */


/*********************************************************************
 * LOCAL FUNCTIONS
 */


/*********************************************************************
 * GLOBAL FUNCTIONS
 */
/**
 * @brief 初始化SD卡硬件
 *
 * 此函数用于初始化SD卡硬件，为后续的SD卡操作做准备。
 * 调用此函数后，SD卡应该处于可操作状态。
 */
extern void hal_sd_init(void);

/**
 * @brief 获取SD卡的状态
 *
 * 此函数用于获取SD卡的当前状态。
 * 返回值表示SD卡的状态，具体含义由实现决定。
 *
 * @return uint8_t SD卡的状态
 */
extern int hal_sd_get_status(void);

/**
 * @brief 反初始化SD卡硬件
 *
 * 此函数用于卸载SD卡文件系统并释放SDMMC主机资源，
 * 将SDMMC总线相关引脚配置为低功耗输入模式。
 * 通常在进入低功耗模式前调用此函数。
 */
extern void hal_sd_deinit(void);

/**
 * @brief 格式化SD卡
 *
 * 对SD卡执行FAT格式化操作。需在SD卡已挂载时调用。
 *
 * @return int 0:成功, -1:失败
 */
extern int hal_sd_format(void);

/** Mounted FAT filesystem capacity/free bytes; returns -1 when unavailable. */
extern int hal_sd_get_space(uint64_t *total, uint64_t *free_bytes);

#ifdef __cplusplus
}
#endif

#endif /* __HAL_SD_H__ */
