#pragma once
#include <stdbool.h>
/* Background delivery can prepare startup; a running user-selected page owns
 * the panel until the user chooses another page. */
static inline bool app_cloud_can_open(bool boot_page,bool image_selected,bool running) {
    return boot_page || (image_selected && !running);
}
static inline bool app_page_holds_auto_sleep(bool menu,bool settings) {
    return menu || settings;
}
